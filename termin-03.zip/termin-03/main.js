// 1.
console.log('>> zadatak 1 <<')

const unorderedList = document.getElementById('list')


// 2.
console.log('>> zadatak 2 <<')

console.log(unorderedList.children[0])

// 3.
console.log('>> zadatak 3 <<')

for (listItem of unorderedList.children) {
    console.log(listItem)
}

// 4.
console.log('>> zadatak 4 <<')

const firstItem = unorderedList.children[0]
firstItem.innerText = "First item (edited)"

// 5.
console.log('>> zadatak 5 <<')

const newElement = document.createElement('li')
newElement.innerHTML = 'Third item'
console.log(newElement)

// 6.
console.log('>> zadatak 6 <<')

const addNewButton = document.querySelector('#add-new')
const firstEventListener = () => console.log("Button clicked!")
addNewButton.addEventListener('click', firstEventListener)

// 7.
console.log('>> zadatak 7 <<')

const inputs = document.getElementsByTagName('input')[0] // uzimamo prvi i jedini element sa tagom "input"

// uklanjamo firstEventListener koji nam je logovao "Button clicked!"
addNewButton.removeEventListener('click', firstEventListener)
addNewButton.addEventListener('click', () => console.log(input.value))

// 8.
console.log('>> zadatak 8 <<')

addNewButton.addEventListener('click', () => {
    const newElement = document.createElement('li')
    newElement.innerHTML = input.value

    unorderedList.appendChild(newElement)

    // dopuna za zadatak 9:
    input.value = ""
})
